import React, { Component } from "react";
import BottomTabNavigator from "./components/BottomTabNavigator";

export default class App extends Component {
  render() {
    //agrega la declaración de retorno para BottomTabNavigator- desafío 4
  }
}
