import React, { Component } from "react";
//Importa las librerias


import TransactionScreen from "../screens/Transaction";
import SearchScreen from "../screens/Search";
// Crea tab

export default class BottomTabNavigator extends Component {
  render() {
    return (
      //Añade el código para añadir navigationcontainer

      
    );
  }
}
